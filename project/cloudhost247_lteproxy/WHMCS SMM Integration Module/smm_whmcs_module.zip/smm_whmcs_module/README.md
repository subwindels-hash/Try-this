# SMM Panel Integration Module for WHMCS

**Version:** 1.0.0  
**WHMCS Compatibility:** 8.9.x  
**PHP Compatibility:** 7.4+ (with IonCube Loader)  

---

## Overview

This module provides full integration between WHMCS and any SMM Panel that uses the Generic SMM API v2 format. It includes:

- **Addon Module:** Admin dashboard, service management, order tracking, API logs, settings
- **Provisioning Module:** Automated order placement when clients purchase products
- **Cron Automation:** Automatic status checking and service syncing
- **Client Area:** Order status display inside client service details

---

## Installation

### Step 1: Upload Files

Upload the module folders to your WHMCS root directory:

```
/modules/addons/smmaddon/
/modules/servers/smmprovisioning/
```

Ensure the following folder structure exists after upload:

```
/modules/addons/smmaddon/
    smmaddon.php
    hooks.php
    /lib/
        AdminDispatcher.php
        ApiClient.php
        Helper.php
    /templates/
        /admin/
            dashboard.php
            services.php
            orders.php
            logs.php
            settings.php

/modules/servers/smmprovisioning/
    smmprovisioning.php
    /templates/
        clientarea.tpl
```

### Step 2: Activate Addon Module

1. Log in to your WHMCS Admin area
2. Navigate to **System Settings > Addon Modules**
3. Find **SMM Panel Integration** and click **Activate**
4. Click **Configure** and enter:
   - SMM Panel API URL (e.g., `https://panel.example.com/api/v2`)
   - SMM Panel API Key
   - Optional: Enable Auto Sync and Debug Mode
5. Save changes

### Step 3: Create Provisioning Server

1. Navigate to **System Settings > Servers**
2. Click **Add New Server**
3. Set:
   - **Name:** SMM Panel Server
   - **Hostname:** Your SMM panel API URL (without `https://`)
   - **Access Hash / Password:** Your API Key
   - **Type:** Select **SMM Panel Provisioning**
4. Click **Test Connection** to verify
5. Save

### Step 4: Create WHMCS Products

1. Navigate to **System Settings > Products/Services**
2. Create a new product group (e.g., "Social Media Marketing")
3. Create a new product:
   - **Product Type:** Other
   - **Module:** SMM Panel Provisioning
   - **Server:** Select your SMM Panel Server
4. In the **Module Settings** tab:
   - Enter the **SMM Service ID** from your SMM panel
   - Set **Minimum Quantity** and **Maximum Quantity**
   - Set custom field names (default: `Link` and `Quantity`)
5. In **Custom Fields** tab, create:
   - Field Name: `Link` (required) - Client enters URL
   - Field Name: `Quantity` (required) - Client enters amount
6. Save the product

### Step 5: Map Services (Optional)

1. Go to **Addons > SMM Panel Integration > Services**
2. Click **Sync Services** to import all services from your SMM panel
3. Use the **Map** button to link SMM services to WHMCS products
4. Set markup percentages or fixed amounts for pricing automation

---

## How It Works

### Order Flow

1. Client orders a product configured with the SMM provisioning module
2. Client enters required custom fields (Link and Quantity) during checkout
3. WHMCS creates the service and triggers module provisioning
4. The module sends an API request to your SMM panel to place the order
5. SMM panel returns an Order ID which is stored in the database
6. Client sees order status in their client area

### Cron Automation

The module hooks into WHMCS daily cron to:

- Sync services list (if Auto Sync enabled)
- Check status of all pending/processing orders
- Update WHMCS service status to match SMM panel status

No additional cron setup is required — it uses the existing WHMCS cron.

---

## Admin Area

Access via **Addons > SMM Panel Integration**:

- **Dashboard:** Overview stats, recent orders
- **Services:** View and map SMM services to WHMCS products
- **Orders:** View all orders, refresh status, cancel orders
- **Logs:** View API request/response logs for debugging
- **Settings:** Configure API URL, API Key, Auto Sync, Debug Mode

---

## Client Area

Clients can view their SMM order status from:
- **Services > [Service Name]**
- The order details show: SMM Order ID, Quantity, Link, Status, Start Count, Remains

---

## API Format Reference

The module uses the **Generic SMM API v2** format which most SMM panels support:

### Authentication
All requests are POST with `key` parameter containing your API key.

### Endpoints

#### 1. Check Balance
```
POST /
action=balance
key=YOUR_API_KEY
```

**Response:**
```json
{
  "balance": "100.50",
  "currency": "USD"
}
```

#### 2. Get Services List
```
POST /
action=services
key=YOUR_API_KEY
```

**Response:**
```json
[
  {
    "service": "123",
    "name": "Instagram Followers",
    "category": "Instagram",
    "rate": "0.50",
    "min": "100",
    "max": "10000",
    "type": "default"
  }
]
```

#### 3. Place Order
```
POST /
action=add
key=YOUR_API_KEY
service=123
link=https://instagram.com/username
quantity=1000
```

**Response (Success):**
```json
{
  "order": 123456789
}
```

**Response (Error):**
```json
{
  "error": "Invalid link"
}
```

#### 4. Check Order Status
```
POST /
action=status
key=YOUR_API_KEY
order=123456789
```

**Response:**
```json
{
  "charge": "0.50",
  "start_count": "100",
  "status": "In progress",
  "remains": "900",
  "currency": "USD"
}
```

#### 5. Refill Order
```
POST /
action=refill
key=YOUR_API_KEY
order=123456789
```

**Response:**
```json
{
  "refill": "12345"
}
```

#### 6. Cancel Order
```
POST /
action=cancel
key=YOUR_API_KEY
order=123456789
```

**Response:**
```json
{
  "cancel": "ok"
}
```

---

## Database Tables

The module creates the following custom tables on activation:

| Table | Purpose |
|-------|---------|
| `mod_smm_config` | Stores module settings |
| `mod_smm_services` | SMM service mappings |
| `mod_smm_orders` | Order tracking |
| `mod_smm_logs` | API request/response logs |
| `mod_smm_server_map` | Per-server API credentials |

---

## Troubleshooting

### Module not appearing in Addon Modules
- Ensure the folder is named exactly `smmaddon`
- Ensure the main file is named exactly `smmaddon.php`
- Check file permissions (755 for directories, 644 for files)

### Test Connection fails
- Verify API URL includes correct path (e.g., `/api/v2`)
- If using hostname in server config, ensure it does NOT include `https://`
- Verify API key is correct and active in SMM panel
- Enable Debug Mode to see detailed logs

### Orders not being placed
- Check that the product has a valid **SMM Service ID** configured
- Ensure custom fields (Link, Quantity) are created and populated
- Check the **Logs** page for API error messages
- Verify the WHMCS service status triggers provisioning (usually "Pending" → "Active")

### Client area shows no order data
- Ensure the provisioning module successfully created the order
- Check the `mod_smm_orders` table for the service ID
- Try manually refreshing the order from the Admin > Orders page

---

## Security Notes

- API keys are stored in WHMCS database. Protect your WHMCS installation.
- All inputs are sanitized before processing.
- cURL uses SSL verification by default.
- No sensitive data is exposed in client area templates.

---

## Uninstallation

1. Deactivate the Addon Module from **System Settings > Addon Modules**
2. Remove server entries from **System Settings > Servers**
3. Optionally drop custom tables:
   - `mod_smm_config`
   - `mod_smm_services`
   - `mod_smm_orders`
   - `mod_smm_logs`
   - `mod_smm_server_map`
4. Delete the module folders from `/modules/addons/` and `/modules/servers/`

---

## Support & Customization

This module is built for generic SMM panels. If your panel uses a different API format, you may need to modify the `ApiClient.php` file to match your panel's request/response structure.

For production use, consider:
- Regular log cleanup to prevent table bloat
- Setting up email notifications for failed orders
- Adding rate limiting if your panel requires it

---

**Developed for WHMCS 8.9.x | PHP 7.4+ | IonCube Compatible**
