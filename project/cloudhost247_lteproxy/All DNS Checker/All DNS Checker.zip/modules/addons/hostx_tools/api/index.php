<?php
/**
 * HostX Tools - API Directory
 * Placeholder for future API endpoints
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
