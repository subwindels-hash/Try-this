{* HostX Tools - Individual Tool Template *}
<div class="hostx-tool-page">
    <div class="hostx-tools-hero hostx-tool-hero">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{$base_url}">Tools Platform</a></li>
                    <li class="breadcrumb-item"><a href="{$base_url}&action=category&cat={$tool.category}">{ucfirst($tool.category)} Tools</a></li>
                    <li class="breadcrumb-item active">{$tool.name}</li>
                </ol>
            </nav>
            <h1><i class="fas {$tool.icon}"></i> {$tool.name}</h1>
            <p class="lead">{$tool.desc}</p>
        </div>
    </div>

    <div class="container hostx-tools-container">
        <div class="row">
            <div class="col-md-8">
                <div class="hostx-tool-workspace">
                    <form id="hostx-tool-form" class="hostx-tool-form" data-tool="{$tool.id}">
                        <input type="hidden" name="csrf_token" value="{$csrf_token}">
                        <input type="hidden" name="tool" value="{$tool.id}">
                        <input type="hidden" name="action" value="ajax">

                        {* Tool-specific form fields rendered by JavaScript based on tool ID *}
                        <div id="hostx-tool-fields"></div>

                        <div class="hostx-tool-actions">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-cogs"></i> Run Tool
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="hostxResetTool()">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                        </div>
                    </form>

                    <div id="hostx-tool-loading" class="hostx-loading" style="display:none;">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <p>Processing... Please wait.</p>
                    </div>

                    <div id="hostx-tool-result" class="hostx-tool-result" style="display:none;">
                        <div class="hostx-result-header">
                            <h3><i class="fas fa-check-circle"></i> Result</h3>
                            <button class="btn btn-sm btn-outline-dark" onclick="hostxCopyResult()">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                        </div>
                        <div id="hostx-result-content" class="hostx-result-content"></div>
                    </div>

                    <div id="hostx-tool-error" class="alert alert-danger" style="display:none;"></div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="hostx-tool-sidebar">
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-info-circle"></i> About This Tool
                        </div>
                        <div class="card-body">
                            <p>{$tool.desc}</p>
                            <p class="text-muted small">Category: {ucfirst($tool.category)}</p>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-header">
                            <i class="fas fa-list"></i> Related Tools
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                {* Get related tools from same category (limited to 5) *}
                                {assign var="relatedCount" value=0}
                                {foreach from=$categories[$tool.category] key=rId item=rTool}
                                    {if $rId != $tool.id && $relatedCount < 5}
                                        <li><a href="{$base_url}&action=tool&tool={$rId}"><i class="fas {$rTool.icon}"></i> {$rTool.name}</a></li>
                                        {assign var="relatedCount" value=$relatedCount+1}
                                    {/if}
                                {/foreach}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    hostxRenderToolForm('{$tool.id}', '{$tool.category}');
});
</script>
