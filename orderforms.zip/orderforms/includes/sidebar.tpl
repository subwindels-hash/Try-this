{foreach $sidebar as $item}
    <div menuItemName="{$item->getName()}" class="panel panel-sidebar {if $item->getClass()}{$item->getClass()}{else}panel-sidebar{/if}{if $item->getExtra('mobileSelect') and $item->hasChildren()} hidden-sm hidden-xs{/if}wgs-side-panels {if $item->getName() eq 'Client Details'}wgs-side-home{/if}"{if $item->getAttribute('id')} id="{$item->getAttribute('id')}"{/if}>
		{if $item->getName() neq 'Client Details'}
			<div class="panel-heading">
				<h3 class="panel-title">
					{$item->getLabel()}
					{if $item->hasBadge()}&nbsp;<span class="badge">{$item->getBadge()}</span>{/if}
					<i class="fas fa-chevron-up panel-minimise pull-right"></i>
				</h3>
			</div>
		{/if}
        {if $item->hasBodyHtml()}
            <div class="panel-body">
				{if $item->getName() eq 'Client Details'}
					{assign var=firstnameClient value=$clientsdetails.firstname|substr:0:1}
					{assign var=lastnameClient value=$clientsdetails.lastname|substr:0:1}
					<div class="wgs-circle-name"><span>{$firstnameClient}{$lastnameClient}</span></div>
					<p class="wgsEditIcon"><a href="{$WEB_ROOT}/clientarea.php?action=details"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></p>
				{/if}
                {$item->getBodyHtml()}
            </div>
        {/if}
        {if $item->hasChildren()}
            <div class="list-group{if $item->getChildrenAttribute('class')} {$item->getChildrenAttribute('class')}{/if}">
                {foreach $item->getChildren() as $childItem}
                    {if $childItem->getUri()}
                        <a menuItemName="{$childItem->getName()}"
                           href="{$childItem->getUri()}"
                           class="list-group-item{if $childItem->isDisabled()} disabled{/if}{if $childItem->getClass()} {$childItem->getClass()}{/if}{if $childItem->isCurrent()} active{/if}"
                           {if $childItem->getAttribute('dataToggleTab')}
                               data-toggle="tab"
                           {/if}
                            {assign "customActionData" $childItem->getAttribute('dataCustomAction')}
							{if is_array($customActionData)}
                               data-active="{$customActionData['active']}"
                               data-identifier="{$customActionData['identifier']}"
                               data-serviceid="{$customActionData['serviceid']}"
                           {/if}
                           {if $childItem->getAttribute('target')}
                               target="{$childItem->getAttribute('target')}"
                           {/if}
                           id="{$childItem->getId()}"
                        >
                            {if is_array($customActionData)}<span class="loading hidden w-hidden" style="display: none;"><i class="fas fa-spinner fa-spin"></i></span>{/if}
                            {if $childItem->hasBadge()}<span class="badge">{$childItem->getBadge()}</span>{/if}
                            {if $childItem->hasIcon()}<i class="{$childItem->getIcon()}"></i>&nbsp;{/if}
                            {$childItem->getLabel()}
                        </a>
                    {else}
                        <div menuItemName="{$childItem->getName()}" class="list-group-item{if $childItem->getClass()} {$childItem->getClass()}{/if}" id="{$childItem->getId()}">
                            {if $childItem->hasBadge()}<span class="badge">{$childItem->getBadge()}</span>{/if}
                            {if $childItem->hasIcon()}<i class="{$childItem->getIcon()}"></i>&nbsp;{/if}
                            {$childItem->getLabel()}
                        </div>
                    {/if}
                {/foreach}
            </div>
        {/if}
        {if $item->hasFooterHtml()}
			{if $item->getName() neq 'Client Details'}
				<div class="panel-footer clearfix">
					{$item->getFooterHtml()}
				</div>
			{/if}
        {/if}
    </div>
    {if $item->getExtra('mobileSelect') and $item->hasChildren()}
        {* Mobile Select only supports dropdown menus *}
        <div class="panel hidden-lg hidden-md {if $item->getClass()}{$item->getClass()}{else}panel-default{/if}"{if $item->getAttribute('id')} id="{$item->getAttribute('id')}"{/if}>
            <div class="panel-heading">
                <h3 class="panel-title">
                    {if $item->hasIcon()}<i class="{$item->getIcon()}"></i>&nbsp;{/if}
                    {$item->getLabel()}
                    {if $item->hasBadge()}&nbsp;<span class="badge">{$item->getBadge()}</span>{/if}
                </h3>
            </div>
            <div class="panel-body">
                <form role="form">
                    <select class="form-control" onchange="selectChangeNavigate(this)">
                        {foreach $item->getChildren() as $childItem}
                            <option menuItemName="{$childItem->getName()}" value="{$childItem->getUri()}" class="list-group-item" {if $childItem->isCurrent()}selected="selected"{/if}>
                                {$childItem->getLabel()}
                                {if $childItem->hasBadge()}({$childItem->getBadge()}){/if}
                            </option>
                        {/foreach}
                    </select>
                </form>
            </div>
            {if $item->hasFooterHtml()}
                <div class="panel-footer">
                    {$item->getFooterHtml()}
                </div>
            {/if}
        </div>
    {/if}
{/foreach}
